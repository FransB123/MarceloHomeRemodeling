jQuery( document ).ready( function($) {
	"use strict";
	//COLORPICKER
	$('.colorpicker').each(function(){
	  $(this).wpColorPicker();
	});
}); 