<?php if (!defined('ABSPATH')) {
    die('Direct access forbidden.');
}

// Post Block style
add_filter( 'ecp_post_style_list_filter','etmunfarid_etcodes_post_style_list_filter' );
function etmunfarid_etcodes_post_style_list_filter($postStyleList) {
    return $postStyleList = array(
		array( 'value' => 'stander-post-style', 'label' => 'Stander Post Style'),
        array( 'value' => 'card-post-style', 'label' => 'Card Post Style'),
        array( 'value' => 'blog-list-style', 'label' => 'List Post Style'),
	);
}