<?php
// Core File
include_once get_template_directory() . '/theme-includes/init.php';